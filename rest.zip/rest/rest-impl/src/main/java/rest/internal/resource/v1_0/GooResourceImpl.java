package rest.internal.resource.v1_0;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.ServiceScope;

import rest.resource.v1_0.GooResource;

/**
 * @author user
 */
@Component(
	properties = "OSGI-INF/liferay/rest/v1_0/goo.properties",
	scope = ServiceScope.PROTOTYPE, service = GooResource.class
)
public class GooResourceImpl extends BaseGooResourceImpl {
}