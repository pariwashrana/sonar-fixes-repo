package rest.internal.resource.v1_0;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.ServiceScope;

import rest.resource.v1_0.FooResource;
import rest.dto.v1_0.Foo;

/**
 * @author user
 */
@Component(properties = "OSGI-INF/liferay/rest/v1_0/foo.properties", scope = ServiceScope.PROTOTYPE, service = FooResource.class)
public class FooResourceImpl extends BaseFooResourceImpl {

	@Override
	public Foo getFoo(Long fooId) {
		Foo foo1 = new Foo() {
			{
				description = "Universal truth must be transcendental.";
				id = 1L;
				name = "Truth";
			}
		};

		return foo1;
	}

}